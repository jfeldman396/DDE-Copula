addpath('/Users/jfeldm01/Library/CloudStorage/OneDrive-Kearney/Documents/Deep-Discrete-Encoders-main/CopDDE/Utilities/')
addpath('/Users/jfeldm01/Library/CloudStorage/OneDrive-Kearney/Documents/Deep-Discrete-Encoders-main/CopDDE//Algorithms/')
addpath('/Users/jfeldm01/Library/CloudStorage/OneDrive-Kearney/Documents/Deep-Discrete-Encoders-main/utilities/')
addpath('/Users/jfeldm01/Library/CloudStorage/OneDrive-Kearney/Documents/Deep-Discrete-Encoders-main/main algorithms/Poisson/')

%%% add paths on your own

K2_true = 3;
K1_true = 10;

J = 50; 

%% ------------------------------------------------------------
% Construct true loading matrices
% -------------------------------------------------------------
B2_sub = zeros(K1_true, K2_true);

max_val = 4;
idx = floor(linspace(1, K1_true, 4));
for i = 1:(length(idx) - 1)
    if mod(i,2) == 0
        B2_sub(idx(i):idx(i+1), i)   = max_val;
        B2_sub(idx(i):idx(i+1), i-1) = -max_val/3;
    else
        B2_sub(idx(i):idx(i+1), i) = max_val;
        if i < length(idx) - 2
            B2_sub(idx(i):idx(i+1), i+1) = -max_val/3;
        end
    end
end

B1_sub = sim_block_loadings(J, K1_true,5,10,5,0,1); % change first 5 to 10 when J = 100

K1_max = floor(J/3);
K2_max = floor(K1_max/3);

B1_true_aug_unscale = zeros(J, K1_max);
B2_true_aug = zeros(K1_max, K2_max);

B1_true_aug_unscale(:,1:K1_true)= B1_sub;
B2_true_aug(1:K1_true,1:K2_true) = B2_sub;

B1_true_aug_unscale = [[-2*ones(floor(J/3),1); -4*ones(floor(J/3),1); -2*ones(J - 2*floor(J/3),1)], B1_true_aug_unscale];
B2_true_aug = [[-2*ones(floor(K1_true/3),1); -ones(floor(K1_true/3),1); -2*ones(K1_true- 2*floor(K1_true/3),1); zeros(K1_max - K1_true,1)], B2_true_aug];

gamma = ones(J,1);

prop_true = 0.5*ones(K2_true,1);

[B1_true_scale, gamma_scale,~] = rescale_B1(prop_true, B2_true_aug(1:K1_true,1:K2_true + 1), B1_true_aug_unscale(:, 1:K1_true + 1), gamma, false,prop_true);
B1_true_aug_scale = zeros(J, K1_max+1);
B1_true_aug_scale(:,1:K1_true+1)= B1_true_scale;

B2_true = B2_true_aug(1:K1_true, 1:K2_true + 1);
lambdas = randi([1, 10], 1, J);
%% main simulation
C = 100; n_vec = [500 1000 2000 4000 8000,16000]; n_parallel = 6;


B1_final_CSP = zeros(J, K1_max+1, length(n_vec), C); B2_final_CSP = zeros(K1_max, K2_max + 1,length(n_vec), C);
B1_final_noCSP = zeros(J, K1_max+1, length(n_vec), C); B2_final_noCSP = zeros(K1_max, K2_max + 1,length(n_vec), C);
B1_final_Gibbs = zeros(J, K1_max+1, length(n_vec), C); B2_final_Gibbs = zeros(K1_max, K2_max + 1,length(n_vec), C);
B1_final_pois= zeros(J, K1_max+1, length(n_vec), C); B2_final_pois = zeros(K1_max, K2_max + 1,length(n_vec), C);

time_CSP = zeros(length(n_vec), C);
time_noCSP = zeros(length(n_vec), C);
time_Gibbs = zeros(length(n_vec), C);
time_pois = zeros(length(n_vec), C);

num_act1_CSP = zeros(length(n_vec), C); num_act2_CSP = zeros(length(n_vec), C);
num_act1_Gibbs = zeros(length(n_vec), C); num_act2_Gibbs = zeros(length(n_vec), C);

for aa = 1:6
    N = n_vec(aa);
    tol = K2_max/2; epsilon = 0.0001;
    pen_1 = N^(2/8); pen_2 = N^(2/8); tau = max(.3,3*N^(-0.3));
    
    
    parfor(c= 1:C)
        rng(50+c);
        
        [Z_true,X,~] = generate_X_Cop_marg_emp(N,prop_true.',...
            lambdas,gamma_scale, B1_true_scale, B2_true_aug(1:K1_true,1:K2_true + 1));

         R = NaN(N, J);

        for j = 1:J
            yj = X(:, j);
            isn = isnan(yj);

            yj_nonan = yj(~isn);
            [~, ~, ic] = unique(yj_nonan, 'sorted');

            R(~isn, j) = ic;
        end

        %% ----------------------------------------------------
        % 3) Number of rank levels per variable
        % -----------------------------------------------------
        Rlevels = zeros(1, J);
        for j = 1:J
            Rlevels(j) = max(R(:, j), [], 'omitnan');
            if isempty(Rlevels(j)) || isnan(Rlevels(j))
                Rlevels(j) = 0;
            end
        end

        Z_init = simulate_gaussian_mixture(X,J);
        tic;
        % spectral initialization
        [prop_in, B1_in, B2_in, gamma_in, A1_in, A2_in] = Normal_init_v2(Z_init, K1_max, K1_max, K2_max,epsilon);
        

        %% CSP
        t = tic;
        [num_act1_CSP(aa,c),num_act2_CSP(aa,c), theta, theta2,gamma_CSP,p,q,A1_sample_long, A2_sample_long,Z,prop_CSP, B1_CSP, B2_CSP, A1_new, A2_new, it_num] = get_SAEM_RL_CSP(X, Z_init, R, Rlevels, prop_in, gamma_in,B1_in, B2_in, A1_in, A2_in, 1, 50,.02,.04,.7,tau); % change to .05 and .1 for J = 100
        time_CSP(aa,c) = toc(t);
        
        [num_act1_CSP(aa,c),num_act2_CSP(aa,c)]
        [B1_final_CSP(:,:,aa,c),B2_final_CSP(:,:,aa,c),~] = format_estimates(B1_true_aug_unscale, B2_true_aug, B1_CSP, B2_CSP,gamma_CSP,prop_CSP,true,Z,true);
    
        %% CSP with VI
        t = tic;
        [num_act1_Gibbs(aa,c),num_act2_Gibbs(aa,c), theta, theta2,gamma_Gibbs,p,q,A1_sample_long, A2_sample_long,Z,prop_Gibbs, B1_Gibbs, B2_Gibbs, A1_new, A2_new, it_num] = get_SAEM_RL_CSP_Gibbs(X, Z_init, R, Rlevels, prop_in, gamma_in,B1_in, B2_in, A1_in, A2_in, 1, 50,.02,.04,.7,tau);
        time_Gibbs(aa,c) = toc(t);

        [B1_final_Gibbs(:,:,aa,c),B2_final_Gibbs(:,:,aa,c),~] = format_estimates(B1_true_aug_unscale, B2_true_aug, B1_Gibbs, B2_Gibbs,gamma_Gibbs,prop_Gibbs,true,Z,true);
        
        %% no CSP -- MLE
        t = tic;
        [gamma_noCSP,p,q,A1_sample_long, A2_sample_long,Z,prop_noCSP, B1_noCSP, B2_noCSP, A1_new, A2_new, it_noCSP] = ...
            get_SAEM_RL(X, Z_init, R, Rlevels, prop_in, B1_in, B2_in, gamma_in, pen_1, pen_2, tau, A1_in, A2_in, 1, tol, 50,.7);
        time_noCSP(aa,c) = toc(t);
        
        [B1_final_noCSP(:,:,aa,c),B2_final_noCSP(:,:,aa,c),~] = format_estimates(B1_true_aug_unscale, B2_true_aug, B1_noCSP, B2_noCSP,gamma_noCSP,prop_noCSP,true,Z,true);

        %% Poisson DDE
        t= tic;
        [prop_pois, B1_pois, B2_pois, A1_final, A2_final, it_pois] = get_SAEM_poisson( ...
             X, prop_in, B1_in, B2_in, pen_1, ...
             pen_2, tau, A1_in, A2_in, 1, tol);

        [B1_final_pois(:,:,aa,c),B2_final_pois(:,:,aa,c),~] = format_estimates(B1_true_aug_unscale, B2_true_aug, B1_pois, B2_pois,gamma_noCSP,prop_pois,false,Z,true);

        time_pois(aa,c) = toc(t);


        fprintf('%d-th iteration complete \n', c);
    end    

end

